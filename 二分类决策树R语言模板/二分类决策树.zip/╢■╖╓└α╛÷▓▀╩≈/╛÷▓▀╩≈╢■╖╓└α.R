#代码解释详细参考网址：https://www.bilibili.com/video/BV1nQ4y1r7KK?share_source=copy_web
#数据解释参考网址：http://archive.ics.uci.edu/ml/datasets/Spambase
library(rpart)
library(rpart.plot)
library(skimr)
library(DataExplorer)
library(caret)
library(pROC)
spambase <- read.csv(file.choose(),header = F)
colnames(spambase) <- read.table(file.choose(),skip = 33,sep = ":",comment.char = "")[,1]
colnames(spambase)[ncol(spambase)] <- "spam"
str(spambase)
skim(spambase)
spambase$spam <- factor(spambase$spam)#应变量转化为因子类型
table(spambase$spam)
#创建训练集【分层抽样】
set.seed(101)
trains <- createDataPartition(
  y=spambase$spam,
  p=0.7,
  list = F
)
traindata <- spambase[trains,]#训练集
testdata <- spambase[-trains,]#验证集
traindata <- testdata
form_cls <- as.formula("spam~.")
# 构建模型
set.seed(100) # 固定交叉验证结果
fit_dt_cls <- rpart(
  form_cls,
  data = traindata,
  method = "class", # 分类模型
  parms = list(split = "gini"), # 分裂规则
  control = rpart.control(cp = 0.001) # 复杂度参数
)
# 原始分类树
fit_dt_cls
# 复杂度相关数据
printcp(fit_dt_cls)
plotcp(fit_dt_cls, upper = "splits")#分裂次数
# 后剪枝
fit_dt_cls_pruned <- prune(fit_dt_cls, cp = 0.0078740)
print(fit_dt_cls_pruned)
plotcp(fit_dt_cls_pruned, upper = "splits")#分裂次数
# 变量重要性
fit_dt_cls_pruned$variable.importance
barplot(fit_dt_cls_pruned$variable.importance)
# 变量重要性图示
varimpdata <- data.frame(importance = fit_dt_cls_pruned$variable.importance)
ggplot(varimpdata,
       aes(x = as.factor(rownames(varimpdata)), y = importance)) +
  geom_col() +
  labs(x = "variables") +
  theme_classic() +
  theme(axis.text.x = element_text(angle = 90, hjust = 1))


# 树形图
# rpart.plot参考文档
prp(fit_dt_cls_pruned,
    type = 2,
    extra = 104,
    tweak = 1,
    fallen.leaves = TRUE,
    main="Decision Tree")

###################

# 预测
# 训练集预测概率
trainpredprob <- predict(fit_dt_cls, newdata = traindata, type = "prob")
trainpredprob <- predict(fit_dt_cls_pruned, newdata = traindata, type = "prob")
# 训练集ROC
trainroc <- roc(response = traindata$spam, predictor = trainpredprob[, 2])
# 训练集ROC曲线
plot(trainroc,
     print.auc = TRUE,
     auc.polygon = TRUE,
     grid = T,
     max.auc.polygon = T,
     auc.polygon.col = "skyblue",
     print.thres = T,
     legacy.axes = T,
     bty = "l")
# 约登法则
bestp <- trainroc$thresholds[
  which.max(trainroc$sensitivities + trainroc$specificities - 1)
]
bestp
# 训练集预测分类
confusionMatrix(data = trainpredlab, # 预测类别
                reference = traindata$AHD, # 实际类别
                positive = "Yes",
                mode = "everything")
